import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admindisplay',
  templateUrl: './admindisplay.component.html',
  styleUrls: ['./admindisplay.component.css']
})
export class AdmindisplayComponent implements OnInit {
user:string;
  constructor() {
    this.user=localStorage.getItem('token');
   }

  ngOnInit() {
  }

}
