import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homedisplay',
  templateUrl: './homedisplay.component.html',
  styleUrls: ['./homedisplay.component.css']
})
export class HomedisplayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
